package model;

import java.io.Serializable;

/**
 *
 * @author sanch
 */
public class ViajeTemporal implements Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private String descripcion;
    private String viajero;
    private DestinoTemporal destino;

    public ViajeTemporal(int id, String descripcion, String viajero, DestinoTemporal destino) {
        this.id = id;
        this.descripcion = descripcion;
        this.viajero = viajero;
        this.destino = destino;
    }

    public int getId() {
        return id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getViajero() {
        return viajero;
    }

    public DestinoTemporal getDestino() {
        return destino;
    }

    @Override
    public String toString() {
        return "ViajeTemporal{" +
                "id=" + id +
                ", descripcion='" + descripcion + '\'' +
                ", viajero='" + viajero + '\'' +
                ", destino=" + destino +
                '}';
    }

    public String toCSV() {
        return id + "," + descripcion + "," + viajero + "," + destino;
    }

    public static String toHeaderCSV() {
        return "id,descripcion,viajero,destino";
    }

    public static ViajeTemporal fromCSV(String linea) {
        String[] datos = linea.trim().split(",");
        int id = Integer.parseInt(datos[0]);
        String descripcion = datos[1];
        String viajero = datos[2];
        DestinoTemporal destino = DestinoTemporal.valueOf(datos[3]);
        return new ViajeTemporal(id, descripcion, viajero, destino);
    }
}
