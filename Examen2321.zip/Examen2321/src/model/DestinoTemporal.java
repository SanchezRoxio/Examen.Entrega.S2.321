package model;
/**
 *
 * @author sanch
 */
public enum DestinoTemporal {
    HILL_VALLEY_1955,
    HILL_VALLEY_2015,
    REALIDAD_ALTERNATIVA,
    FAR_WEST_1885,
    LINEA_RESTAURADA
}
