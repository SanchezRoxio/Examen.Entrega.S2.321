package service;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 *
 * @author sanch
 */
public class LibroDeViajes<T> {

    private List<T> elementos = new ArrayList<>();

    public void agregar(T item) {
        elementos.add(item);
    }

    public void limpiar() {
        elementos.clear();
    }

    public int tamanio() {
        return elementos.size();
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        elementos.forEach(accion);
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> res = new ArrayList<>();
        for (T e : elementos) {
            if (criterio.test(e)) {
                res.add(e);
            }
        }
        return res;
    }

    public void ordenar(Comparator<? super T> comp) {
        elementos.sort(comp);
    }

    public List<T> getElementos() {
        return new ArrayList<>(elementos);
    }

    public void setElementos(List<T> lista) {
        elementos.clear();
        if (lista != null) {
            elementos.addAll(lista);
        }
    }
}