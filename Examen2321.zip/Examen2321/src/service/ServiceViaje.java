package service;
/**
 *
 * @author sanch
 */
import java.util.List;
import model.ViajeTemporal;
import model.DestinoTemporal;

public class ServiceViaje {

    public static void hardcodearViajes(List<? super ViajeTemporal> lista) {
        lista.add(new ViajeTemporal(1, "Salvar a George McFly", "Marty McFly",
                DestinoTemporal.HILL_VALLEY_1955));
        lista.add(new ViajeTemporal(2, "Buscar el Almanaque Deportivo", "Marty McFly",
                DestinoTemporal.HILL_VALLEY_2015));
        lista.add(new ViajeTemporal(3, "Impedir la realidad alternativa de Biff", "Doc Brown",
                DestinoTemporal.REALIDAD_ALTERNATIVA));
        lista.add(new ViajeTemporal(4, "Rescatar a Clara en el puente", "Doc Brown",
                DestinoTemporal.FAR_WEST_1885));
        lista.add(new ViajeTemporal(5, "Restaurar la línea temporal original", "Marty McFly",
                DestinoTemporal.LINEA_RESTAURADA));
    }
    public static void listarViajes(List<? extends ViajeTemporal> lista) {
        lista.forEach(System.out::println);
    }
}
