package examen2321;
import config.RutasArchivos;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import model.DestinoTemporal;
import model.ViajeTemporal;
import persistence.PersistenciaViajes;
import service.LibroDeViajes;
/**
 *
 * @author sanch
 */
public class Main {
    public static void main(String[] args) {
        try {
            LibroDeViajes<ViajeTemporal> libro = new LibroDeViajes<>();

            libro.agregar(new ViajeTemporal(1, "Salvar a George McFly",
                    "Marty McFly", DestinoTemporal.HILL_VALLEY_1955));
            libro.agregar(new ViajeTemporal(2, "Buscar el Almanaque Deportivo",
                    "Marty McFly", DestinoTemporal.HILL_VALLEY_2015));
            libro.agregar(new ViajeTemporal(3, "Impedir la realidad alternativa de Biff",
                    "Doc Brown", DestinoTemporal.REALIDAD_ALTERNATIVA));
            libro.agregar(new ViajeTemporal(4, "Rescatar a Clara en el puente",
                    "Doc Brown", DestinoTemporal.FAR_WEST_1885));
            libro.agregar(new ViajeTemporal(5, "Restaurar la línea temporal original",
                    "Marty McFly", DestinoTemporal.LINEA_RESTAURADA));

            System.out.println("Viajes en el tiempo:");
            libro.paraCadaElemento(v -> System.out.println(v));

            System.out.println("\nViajes a 1955:");
            libro.filtrar(v -> v.getDestino() == DestinoTemporal.HILL_VALLEY_1955)
                 .forEach(v -> System.out.println(v));

            System.out.println("\nViajes que contienen 'almanaque':");
            libro.filtrar(v -> v.getDescripcion().toLowerCase().contains("almanaque"))
                 .forEach(v -> System.out.println(v));

            System.out.println("\nViajes ordenados por ID:");
            libro.ordenar((v1, v2) -> Integer.compare(v1.getId(), v2.getId()));
            libro.paraCadaElemento(v -> System.out.println(v));

            System.out.println("\nViajes ordenados por descripción:");
            libro.ordenar(Comparator.comparing(ViajeTemporal::getDescripcion));

            String rutaBin = RutasArchivos.getRutaBINString();
            PersistenciaViajes.serializarViajes(libro.getElementos(), rutaBin);

            LibroDeViajes<ViajeTemporal> libroCargado = new LibroDeViajes<>();
            List<ViajeTemporal> listaBin = PersistenciaViajes.deserializarViajes(rutaBin);
            libroCargado.setElementos(listaBin);

            System.out.println("\nViajes cargados desde archivo binario:");       
            libroCargado.paraCadaElemento(v -> System.out.println(v));
            String rutaCsv = RutasArchivos.getRutaCSVString();
            PersistenciaViajes.guardarViajesCSV(libro.getElementos(), rutaCsv);
            List<ViajeTemporal> listaCsv = PersistenciaViajes.cargarViajesCSV(rutaCsv);
            libroCargado.setElementos(listaCsv);

            System.out.println("\nViajes cargados desde archivo CSV:");
 
            libroCargado.paraCadaElemento(v -> System.out.println(v));

        } catch (IOException | ClassNotFoundException e) {  
            System.err.println("Error: " + e.getMessage());
        }
    }
}