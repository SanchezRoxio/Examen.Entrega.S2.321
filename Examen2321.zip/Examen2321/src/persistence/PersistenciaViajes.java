package persistence;
/**
 *
 * @author sanch
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;
import model.ViajeTemporal;

public class PersistenciaViajes {
    
    public static void guardarViajesCSV(List<? extends ViajeTemporal> lista, String path) {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            
            escritor.write(ViajeTemporal.toHeaderCSV());
            escritor.newLine();
            
            for (ViajeTemporal v : lista) {
                escritor.write(v.toCSV());
                 escritor.newLine(); 
            }
        } catch (IOException ex) {
            System.out.println("Error al guardar CSV: " + ex.getMessage());
        }
    }

    public static List<ViajeTemporal> cargarViajesCSV(String path) {
        List<ViajeTemporal> toReturn = new ArrayList<>();
        
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String linea;
            lector.readLine();
            
            while ((linea = lector.readLine()) != null) {
                if (!linea.isBlank()) {
                    toReturn.add(ViajeTemporal.fromCSV(linea));
                }
            }
        } catch (IOException ex) {
            System.out.println("Error al leer CSV: " + ex.getMessage());
        }
        
        return toReturn;
    }

    public static void serializarViajes(List<? extends ViajeTemporal> lista, String path) {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            serializador.writeObject(lista);
        } catch (IOException ex) {
            System.out.println("Error al serializar: " + ex.getMessage());
        }
    }

   public static List<ViajeTemporal> deserializarViajes(String path) 
            throws IOException, ClassNotFoundException {     
        try (ObjectInputStream deser = new ObjectInputStream(new FileInputStream(path))) {
            return (List<ViajeTemporal>) deser.readObject();
        }
    }
}